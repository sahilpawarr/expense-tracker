# Models moved to app.py to avoid circular imports
from app import Configuration, FamilyMember, Expense, Budget, DEFAULT_CATEGORIES